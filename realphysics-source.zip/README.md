`bundle/` is the mod. `simtest/` runs its physics with no game. See `bundle/README.md`.
